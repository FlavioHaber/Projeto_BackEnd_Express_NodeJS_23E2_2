import { Outlet } from "react-router-dom";
import { ClienteForm } from "../@Type/ClienteForm";
import {createContext, useState } from "react";

type props = {
    clienteState: ClienteForm[],
    setclienteState : Function
}

export const ClienteContext = createContext<props>({
    clienteState: [],
    setclienteState: () => {}
    }
)

export const Cadastro = () => {
    const [clienteState, setclienteState] = useState<ClienteForm[]>([])

    return (
        <>
        <ClienteContext.Provider value={{clienteState,setclienteState}}>
            <Outlet/>
        </ClienteContext.Provider>
        </>
    )
}