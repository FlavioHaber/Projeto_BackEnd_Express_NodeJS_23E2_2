import Header from "../components/Header";
import Footer from "../components/Footer";
import { Cadastro } from "../Context/ClienteContext";

const Home = () => {
    return (
        <>
          <Header />
          <Cadastro />
          <Footer />
        </>
        
    )
}

export default Home