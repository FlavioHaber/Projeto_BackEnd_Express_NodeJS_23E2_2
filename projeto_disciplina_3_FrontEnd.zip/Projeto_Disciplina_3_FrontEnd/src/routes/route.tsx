import { createBrowserRouter } from "react-router-dom";
import NotFound404 from "./NotFound404";
import PageCadastro from "../pages/PageCadastro";
import PageCadastroRemover from "../pages/PageCadastroRemover";
import PageCadastroAlterar from "../pages/PageCadastroAlterar";
import PageLista from "../pages/PageLista";
import Home from "../layout/Home";

export default createBrowserRouter([   
   {
    errorElement: <NotFound404 />
  },
  {
    path: "",
   element: <Home />,
    children: [
        {
          path: "/",
          element: <PageCadastro />
        },
        {
          path: "/Listagem",
          element: <PageLista />
        },
        {
          path: "/Remover",
          element: <PageCadastroRemover />
        },
        {
          path: "/Alterar",
          element: <PageCadastroAlterar />
        }

      ]
    }
  ]
)

