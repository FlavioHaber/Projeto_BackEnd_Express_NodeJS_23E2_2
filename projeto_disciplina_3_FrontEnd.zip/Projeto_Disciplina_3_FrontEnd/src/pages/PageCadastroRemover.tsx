import { Button, Card, CardActions, CardContent, Grid, Stack } from "@mui/material"
import styled from "@emotion/styled"
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { ClienteForm } from "../@Type/ClienteForm";
import axios from 'axios';

const PageCadastroRemover = () => {

    const { register, handleSubmit, formState: { errors }} = useForm<ClienteForm>();

    const onSubmit = async (data: ClienteForm) => {
        try {
            const response = await axios.delete('http://localhost:3333/clientes/' + data.id);
            console.log(response.data)    
        } catch (error) {
            alert(error)     
        }
    }
  
    return (
        <>
        <Grid container direction={"row"} justifyContent={"center"} alignItems={"center"}>
            <PageCadastroRemover.Card>
                <h1>Cadastro de Cliente</h1>
                <hr/>
                <PageCadastroRemover.CardContent>
                    <form onSubmit={handleSubmit(onSubmit)}>
                      <Stack spacing={1}>
                            <PageCadastroRemover.label>
                               Id
                            </PageCadastroRemover.label>
                            <PageCadastroRemover.input type="text" {...register("id")} />
                            {errors.id?.type === 'required' && <h5>O ID do Cliente deve ser preenchido. Você poderá copiá-lo na tela de clientes cadastrados.</h5>}
                            <hr/>
                            <Button type="submit" variant="contained"  size="large" >
                                Remover
                            </Button>
                        </Stack>   
                    </form>    
                </PageCadastroRemover.CardContent>
                <CardActions>
                   <Grid container spacing={2}>
                       <Grid item xs={12} textAlign="center">
                            <PageCadastroRemover.Link to="/">Tela inicial</PageCadastroRemover.Link>
                            <PageCadastroRemover.Link to="/Listagem">Clientes cadastrados</PageCadastroRemover.Link>
                            <PageCadastroRemover.Link to="/Alterar">Alterar</PageCadastroRemover.Link>
                       </Grid>
                    </Grid>
                </CardActions>
            </PageCadastroRemover.Card>
        </Grid>
        </>
      )
}

PageCadastroRemover.Card = styled(Card)`
background-color: snow;
margin-top: 100px;
text-align: center;
border-radius: 20px;
width: 450px;
`
PageCadastroRemover.CardContent = styled(CardContent)`
    display: flex;
    flex-direction: column;
    text-align: left;
`
PageCadastroRemover.label = styled.label`
`
PageCadastroRemover.input = styled.input`
    width: 400px;
    height : 1.5rem;
`
PageCadastroRemover.select = styled.select`
     width: 415px;
    height : 2rem;
`
PageCadastroRemover.Link = styled(Link)`
    padding-left: 10px;
    padding-right:10px;
`
export default PageCadastroRemover

