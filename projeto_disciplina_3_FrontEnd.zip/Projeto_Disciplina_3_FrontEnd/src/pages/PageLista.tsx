import { Link } from "react-router-dom";
import {useState} from "react";
import styled from "@emotion/styled";
import { Card, CardContent, Stack, Grid, Avatar, CardHeader, Typography, Rating } from "@mui/material";
import InsertEmoticonIcon from '@mui/icons-material/InsertEmoticon';
import { deepOrange } from '@mui/material/colors';
import axios from "axios";
import {useEffect} from "react"
import { ClienteForm } from "../@Type/ClienteForm";

const PageLista = () => {
        const [clienteState, setclienteState] = useState<ClienteForm[]>([])
     
        const consultaCliente = async () => {
            try {
                const response = await axios.get('http://localhost:3333/clientes');
                setclienteState(response.data)
                console.log(response.data)
            } catch (error) {
                alert(error)     
            }
        }

        useEffect(()=>{consultaCliente();}, [setclienteState])
    return (
        <>
         <PageLista.Grid container spacing={2}>
            <Grid item xs={6} textAlign="left">
                <h3>Listagem de Clientes Cadastrados</h3>                 
            </Grid>
            <Grid item xs={6} textAlign="end">
                <PageLista.Link to="/">Página inicial</PageLista.Link>
            </Grid>
        </PageLista.Grid>
        <PageLista.Container >
            <Grid container spacing={1}>
                    <>
                        {clienteState.map((cadastro) => (
                        <Stack spacing={2} direction={"row"}>
                            <PageLista.Card>
                                <CardHeader
                                    avatar={
                                    <Avatar sx={{ bgcolor: deepOrange[200], width: 56, height: 56}} >
                                        <PageLista.InsertEmoticonIcon /> 
                                    </Avatar>
                                    }
                                    title= {<h2>Cliente cadastrado</h2>}
                                />
                                <hr/>
                                <CardContent>
                                    <Stack direction={"column"} spacing={1}>
                                        <PageLista.label>
                                            Id:
                                        </PageLista.label>
                                        <label>
                                            {cadastro.id}
                                        </label>
                                        <PageLista.label>
                                            Nome:
                                        </PageLista.label>
                                        <label>
                                            {cadastro.nome}
                                        </label>
                                        <PageLista.label>
                                            Endereço:
                                        </PageLista.label>
                                        <label> 
                                            {cadastro.endereco}
                                        </label>
                                        <PageLista.label>
                                            Bairro:
                                        </PageLista.label>
                                        <label> 
                                            {cadastro.bairro}
                                        </label>
                                        <PageLista.label>
                                            Cidade:
                                        </PageLista.label>
                                        <label> 
                                            {cadastro.cidade}
                                        </label>
                                        <PageLista.label>
                                            Estado:
                                        </PageLista.label>
                                        <label> 
                                            {cadastro.estado}
                                        </label>
                                        <hr/>
                                        <Typography component="legend">10 estrelas</Typography>
                                        <Rating name="customized-10" defaultValue={10} max={10} readOnly/>
                                    </Stack>
                                </CardContent>
                            </PageLista.Card>
                        </Stack>
                        )
                        )}
                    </>
            </Grid>
        </PageLista.Container>
        </>
    )    
}

PageLista.Container = styled.div`
    display: flex;
    flex-direction: row;
    flex-wrap: wrap ;
    justify-content: space-between;
    align-content: flex-start;
    width:100%;
    height:1500px;
`
PageLista.Card = styled(Card)`
    margin: 20px;
    background-color: WhiteSmoke;
    font-size: 15px;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
`
PageLista.InsertEmoticonIcon = styled(InsertEmoticonIcon)`
  font-size: 60px;
`
PageLista.Link = styled(Link)`
   padding-right: 10px;
`
PageLista.Grid = styled(Grid)`
    padding-left: 10px;
`
PageLista.img = styled.img`
width: 80px;
height: 80px;
`
PageLista.label = styled.label`
    font-weight: bold;
    font-size: 1rem;
`
export default PageLista