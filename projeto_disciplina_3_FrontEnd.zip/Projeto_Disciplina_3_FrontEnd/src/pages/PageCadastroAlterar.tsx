import { Button, Card, CardActions, CardContent, Grid, Stack } from "@mui/material"
import styled from "@emotion/styled"
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { ClienteForm } from "../@Type/ClienteForm";
import axios from 'axios';

const PageCadastroAlterar = () => {
    const { register, handleSubmit, formState: { errors }} = useForm<ClienteForm>();

    const onSubmit = async (data: ClienteForm) => {
        try {
            const response = await axios.put('http://localhost:3333/clientes/' + data.id, {
              "nome":data.nome,
              "endereco":data.endereco,
              "bairro":data.bairro,
              "cidade":data.cidade,
              "estado":data.estado
            });
            console.log(response.data)    
        } catch (error) {
            alert(error)     
        }
    }

    return (
        <>
        <Grid container direction={"row"} justifyContent={"center"} alignItems={"center"}>
            <PageCadastroAlterar.Card>
                <h1>Cadastro de Cliente</h1>
                <hr/>
                <PageCadastroAlterar.CardContent>
                    <form onSubmit={handleSubmit(onSubmit)}>
                      <Stack spacing={1}>
                             <PageCadastroAlterar.label>
                                Id
                            </PageCadastroAlterar.label>
                            <PageCadastroAlterar.input type="text" {...register("id", 
                                    {required: true}
                                    )
                                }
                            />
                            {errors.id?.type === 'required' && <h5>O ID do Cliente deve ser preenchido. Você poderá copiá-lo na tela de clientes cadastrados.</h5>}
                            <PageCadastroAlterar.label>
                                Nome
                            </PageCadastroAlterar.label>
                            <PageCadastroAlterar.input type="text" {...register("nome", 
                                    {required: true, 
                                    minLength: 10, 
                                    maxLength: 150}
                                    )
                                }
                            />
                            {errors.nome?.type === 'required' && <h5>O nome deve ser preenchido.</h5>}
                            {errors.nome?.type === 'maxLength' && <h5>O nome deve ter até 150 caracteres.</h5>}
                            {errors.nome?.type === 'minLength' && <h5>O nome deve ter mais de 9 caracteres.</h5>}
                            <PageCadastroAlterar.label>
                                Endereço
                            </PageCadastroAlterar.label>
                            <PageCadastroAlterar.input type="text" {...register("endereco",
                                    {required: true, 
                                    minLength: 20, 
                                    maxLength: 150}
                                    )
                                }
                            />
                            {errors.endereco?.type === 'required' && <h5>O endereço deve ser preenchido</h5>}
                            {errors.endereco?.type === 'maxLength' && <h5>O endereço deve ter até 150 caracteres.</h5>}
                            {errors.endereco?.type === 'minLength' && <h5>O endereço deve ter mais de 19 caracteres.</h5>}
                            <PageCadastroAlterar.label>
                                Bairro
                            </PageCadastroAlterar.label>
                            <PageCadastroAlterar.input type="text" {...register("bairro",
                                    {required: true, 
                                    minLength: 5, 
                                    maxLength: 100}
                                    )
                                }
                            />
                            {errors.bairro?.type === 'required' && <h5>O bairro deve ser preenchido</h5>}
                            {errors.bairro?.type === 'maxLength' && <h5>O bairro deve ter até 100 caracteres.</h5>}
                            {errors.bairro?.type === 'minLength' && <h5>O bairro deve ter mais de 4 caracteres. </h5>}
                            <PageCadastroAlterar.label>
                                Cidade
                            </PageCadastroAlterar.label>
                            <PageCadastroAlterar.input type="text" {...register("cidade", 
                                    {required: true, 
                                    minLength: 2, 
                                    maxLength: 100}
                                    )
                                }
                            />
                            {errors.cidade?.type === 'required' && <h5>A cidade deve ser preenchida</h5>}
                            {errors.cidade?.type === 'maxLength' && <h5>A cidade deve ter até 100 caracteres.</h5>}
                            {errors.cidade?.type === 'minLength' && <h5>A cidade dever ter mais de 2 caracteres.</h5>}
                            <PageCadastroAlterar.label>
                                Estado
                            </PageCadastroAlterar.label>
                            <PageCadastroAlterar.select defaultValue={"RJ"} {...register("estado", 
                                        {required: true}
                                    )
                                }>
                                <option value="ES">ES</option>
                                <option value="MG">MG</option>
                                <option value="RJ">RJ</option>
                                <option value="SP">SP</option>
                            </PageCadastroAlterar.select>
                            <hr/>
                            <Button type="submit" variant="contained"  size="large" >
                                Alterar
                            </Button>
                        </Stack>   
                    </form>    
                </PageCadastroAlterar.CardContent>
                <CardActions>
                   <Grid container spacing={2}>
                       <Grid item xs={12} textAlign="center">
                            <PageCadastroAlterar.Link to="/">Tela Inicial</PageCadastroAlterar.Link>    
                            <PageCadastroAlterar.Link to="/Listagem">Clientes cadastrados</PageCadastroAlterar.Link>
                            <PageCadastroAlterar.Link to="/Remover">Remover</PageCadastroAlterar.Link>
                       </Grid>
                    </Grid>
                </CardActions>
            </PageCadastroAlterar.Card>
        </Grid>
        </>
      )
}

PageCadastroAlterar.Card = styled(Card)`
background-color: snow;
margin-top: 100px;
text-align: center;
border-radius: 20px;
width: 450px;
`
PageCadastroAlterar.CardContent = styled(CardContent)`
    display: flex;
    flex-direction: column;
    text-align: left;
`
PageCadastroAlterar.label = styled.label`
`
PageCadastroAlterar.input = styled.input`
    width: 400px;
    height : 1.5rem;
`
PageCadastroAlterar.select = styled.select`
     width: 415px;
    height : 2rem;
`
PageCadastroAlterar.Link = styled(Link)`
    padding-left: 10px;
    padding-right:10px;
`
export default PageCadastroAlterar

