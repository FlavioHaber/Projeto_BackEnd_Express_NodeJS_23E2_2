import { render, screen } from "@testing-library/react";
import PageDois from "../../pages/PageCadastro";
import {RouteTest, ThemeTest} from "../shared/Logics";

test('Deve apresentar os campos do formulário: Input - Combobox, devendo existir 4 opções de UF no combobox ', () => {
    //arrange
        render(
           <ThemeTest>
              <RouteTest>
                  <PageDois />
              </RouteTest>
            </ThemeTest>
            )
    //act
    //assert
        expect(screen.getAllByRole('textbox')).toHaveLength(4)
        expect(screen.getAllByRole('combobox')).toHaveLength(1)
        expect(screen.getAllByRole('option')).toHaveLength(4)
})

test('Deve existir um botão habilitado no formulário e um link para página de listagem', () => {
    // arrange
    render(
        <ThemeTest>
           <RouteTest>
               <PageDois />
           </RouteTest>
         </ThemeTest>
         )
    //act
    //assert
    expect(screen.getByRole('button')).not.toBeDisabled()
    expect(screen.getAllByRole('button')).toHaveLength(1)
    expect(screen.getAllByRole('link')).toHaveLength(1)
})

