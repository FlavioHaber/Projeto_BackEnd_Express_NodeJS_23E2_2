import { BrowserRouter } from "react-router-dom";
import { createTheme, ThemeProvider } from "@mui/material";
import React from "react";

type TestProp ={
    children : React.ReactNode
}

export const RouteTest =({children}: TestProp) => (
    <BrowserRouter>{children}</BrowserRouter>
)

export const ThemeTest = ({children}: TestProp) => (
    <ThemeProvider theme={createTheme({})}>{children}</ThemeProvider>
)
