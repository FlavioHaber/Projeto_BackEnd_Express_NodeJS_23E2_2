const {v4 : uuidv4} = require('uuid')
const {validateDataCliente} = require('../model/clienteModel')
const path = require('path')
const pathfile = path.join(__dirname,'/clientes.json')

const fs = require('fs')

//--------> GET
function getClientesPromise()
{
    return new Promise((resolve, reject) => {
        fs.readFile(pathfile, 'utf8', (err, data) => {  
            if (err) {
                reject(err)
            }
            else {
                let clientes = JSON.parse(data)
                resolve(clientes)
            }
        })

      }    
    )
}

const getClientes = (req, res) => {
    getClientesPromise()
    .then(clientes => res.status(200).json(clientes))
    .catch(err => res.status(500).send(err.message));
}

//--------> POST
function addClientesPromise(cliente)
{
    return new Promise((resolve, reject) => {
        fs.readFile(pathfile, 'utf8', (err, data) => {
            console.log(pathfile + '1')
            if (err) {
                reject(err);
            }
            else {
                let clientes = JSON.parse(data)

                const id = uuidv4()
                const clienteNovo = {id, ...cliente}

                clientes.push(clienteNovo)

                fs.writeFile(pathfile, JSON.stringify(clientes), (err) => {
                    console.log(pathfile+'2') 
                    if (err) {
                        reject(err);
                    } else {
                        resolve(clienteNovo);
                    }
                })
            }
        })       
    })
}

const addClientes = (req, res) => {
    const cliente = req.body
    
    const validResult = validateDataCliente(cliente)

    if (!validResult.valid)
    {
        return res.status(400).json({message:'Dados do cliente inválido', errors : validResult.errors})
    }

    addClientesPromise(cliente)
    .then(clienteNovo => res.status(200).json(clienteNovo))
    .catch(err => res.status(500).send(err.message))
}

//--------> PUT
function updateClientesPromise(id, cliente)
{
    return new Promise((resolve, reject) => {
        fs.readFile(pathfile, 'utf8', (err, data) => {
            if (err) {
                reject(err)
            } 
            else {
                let clientes = JSON.parse(data)  

                const index = clientes.findIndex((e)=> e.id === id)

                if (index === -1) {
                    reject(new Error('Cliente não encontrado'))
                }
                else {
                    const clienteUpdate = {...clientes[index], ...cliente}

                    clientes[index] = clienteUpdate

                    fs.writeFile(pathfile, JSON.stringify(clientes), (err) => {
                        if (err) {
                            reject(err)
                        } else {
                            resolve(clienteUpdate)
                        }
                    })
                }

            }
        })
    })
}

const updateClientes = (req, res) => {
    const id = req.params.id
    const cliente = req.body
    updateClientesPromise(id, cliente)
    .then(clienteUpdate => res.status(200).json(clienteUpdate))
    .catch(err => res.status(500).send(err.message))
}


//--------> DELETE

function removeClientesPromise(id)
{
    return new Promise((resolve, reject) => {
        fs.readFile(pathfile, 'utf8',(err, data) => {
            if (err) {
                reject(err)
            } else {
                const clientes = JSON.parse(data)

                const index = clientes.findIndex((e) => e.id === id)

                if (index === -1) {
                    reject(new Error('Cliente não encontrado'))
                } else {
                    clientes.splice(index, 1)

                    fs.writeFile(pathfile, JSON.stringify(clientes), err => {
                        if (err) {
                            reject(err)
                        } else {
                            resolve()
                        }
                    })
                }
            }
        })
    })
}

const removeClientes = (req, res) => {
    const id = req.params.id
    removeClientesPromise(id)
    .then(() => res.status(200).json({message: "Cliente Deletado"}))
    .catch(err => res.status(500).send(err.message))
}

module.exports = {getClientes, addClientes, updateClientes, removeClientes}