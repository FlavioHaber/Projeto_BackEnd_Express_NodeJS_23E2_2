const express = require('express')
const router = express.Router()

const clienteController = require('../controller/clientesController')

router.get('/', clienteController.getClientes)

router.post('/add', clienteController.addClientes)

router.put('/:id', clienteController.updateClientes)

router.delete('/:id', clienteController.removeClientes)

module.exports = router
