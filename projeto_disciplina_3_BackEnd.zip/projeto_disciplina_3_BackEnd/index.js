const express = require('express')
const cors = require('cors')
const app = express()

const clienteRoutes = require('./routes/clienteRoutes')

const host = '127.0.0.1'
const port = 3333

app.use(cors("http://localhost:3333/clientes"))
app.use(express.json())
app.use('/clientes', clienteRoutes)


app.listen(port, host, ()=>{
    console.log(`Server running at http://${host}:${port}`)
})